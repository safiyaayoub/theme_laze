
=====
Theme Installation guide
=====

1. Download theme_laze module

2. Add downloaded module in addons path

3. Go to apps and update applist.

4. Click on install theme_laze.

5. After install this module you will redirect to choose theme for your website page.

